local isTrunkOpen = false

RegisterCommand('vehicleControl', function()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then return end
    openVehicleMenu()
end)

RegisterKeyMapping('vehicleControl', 'Open Vehicle Control Menu', 'keyboard', 'G')

function openVehicleMenu()
    lib.registerContext({
        id = 'vehicle_control_menu',
        title = 'Vehicle Control',
        options = {
            {
                title = '🗑️ Remove Individual Doors',
                menu = 'remove_doors_menu'
            },
            {
                title = '🗑️ Remove All Doors',
                onSelect = removeAllDoors
            },
            {
                title = isTrunkOpen and '🔒 Close Trunk' or '🔓 Open Trunk',
                onSelect = toggleTrunk
            },
            {
                title = '🔁 Change Seat',
                menu = 'change_seat_menu'
            }
        }
    })

    lib.registerContext({
        id = 'remove_doors_menu',
        title = 'Remove Doors',
        menu = 'vehicle_control_menu',
        options = {
            { title = '🚪 Front Left Door', onSelect = function() breakDoor(0) end },
            { title = '🚪 Front Right Door', onSelect = function() breakDoor(1) end },
            { title = '🚪 Rear Left Door', onSelect = function() breakDoor(2) end },
            { title = '🚪 Rear Right Door', onSelect = function() breakDoor(3) end },
            { title = '🛞 Hood', onSelect = function() openPart(4) end },
            { title = '📦 Trunk', onSelect = function() breakDoor(5) end },
        }
    })

    lib.registerContext({
        id = 'change_seat_menu',
        title = 'Change Seat',
        menu = 'vehicle_control_menu',
        options = {
            { title = '👤 Driver Seat', onSelect = function() changeSeat(-1) end },
            { title = '👤 Front Passenger', onSelect = function() changeSeat(0) end },
            { title = '👤 Rear Left', onSelect = function() changeSeat(1) end },
            { title = '👤 Rear Right', onSelect = function() changeSeat(2) end },
        }
    })

    lib.showContext('vehicle_control_menu')
end

function breakDoor(index)
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    SetVehicleDoorBroken(vehicle, index, true)
    lib.notify({ title = 'Vehicle Control', description = 'Part removed', type = 'error' })
end

function openPart(index)
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    SetVehicleDoorOpen(vehicle, index, false, false)
    lib.notify({ title = 'Vehicle Control', description = 'Part opened', type = 'info' })
end

function removeAllDoors()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    for i = 0, 3 do
        SetVehicleDoorBroken(vehicle, i, true)
    end
    SetVehicleDoorOpen(vehicle, 5, false, false) 
    lib.notify({ title = 'Vehicle Control', description = 'Side doors removed, trunk opened', type = 'error' })
end

function toggleTrunk()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    if isTrunkOpen then
        SetVehicleDoorShut(vehicle, 5, false)
        isTrunkOpen = false
        lib.notify({ title = 'Vehicle Control', description = 'Trunk closed', type = 'info' })
    else
        SetVehicleDoorOpen(vehicle, 5, false, false)
        isTrunkOpen = true
        lib.notify({ title = 'Vehicle Control', description = 'Trunk opened', type = 'info' })
    end
end

function changeSeat(seatIndex)
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if IsVehicleSeatFree(vehicle, seatIndex) then
        TaskWarpPedIntoVehicle(ped, vehicle, seatIndex)
        lib.notify({ title = 'Vehicle Control', description = 'Moved to seat', type = 'success' })
    else
        lib.notify({ title = 'Vehicle Control', description = 'Seat is occupied', type = 'error' })
    end
end


RegisterCommand('vehicleLockToggle', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if vehicle == 0 then
        vehicle = GetClosestVehicle(GetEntityCoords(ped), 7.0, 0, 70)
    end

    if vehicle ~= 0 then
        local locked = GetVehicleDoorLockStatus(vehicle)
        if locked == 1 or locked == 0 then
            SetVehicleDoorsLocked(vehicle, 2)
            SetVehicleDoorsLockedForAllPlayers(vehicle, true)
            lib.notify({ title = 'Vehicle Control', description = 'Vehicle locked', type = 'warning' })
        else
            SetVehicleDoorsLocked(vehicle, 1)
            SetVehicleDoorsLockedForAllPlayers(vehicle, false)
            lib.notify({ title = 'Vehicle Control', description = 'Vehicle unlocked', type = 'success' })
        end
    else
        lib.notify({ title = 'Vehicle Control', description = 'No vehicle found nearby', type = 'error' })
    end
end)

RegisterKeyMapping('vehicleLockToggle', 'Toggle Vehicle Lock', 'keyboard', 'L')


RegisterCommand('rd', function()
    removeAllDoors()
end)

function flashLights(vehicle)
    for i = 1, 2 do
        SetVehicleLights(vehicle, 2)
        Wait(150)
        SetVehicleLights(vehicle, 0)
        Wait(150)
    end
end

function playLockSound(vehicle, locked)
    TriggerServerEvent('InteractSound_SV:PlayOnSource', locked and 'lock' or 'unlock', 0.3)
end

RegisterCommand('vehicleLockToggle', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then
        vehicle = GetClosestVehicle(GetEntityCoords(ped), 7.0, 0, 70)
    end

    if vehicle ~= 0 then
        local locked = GetVehicleDoorLockStatus(vehicle)
        if locked == 1 or locked == 0 then
            SetVehicleDoorsLocked(vehicle, 2)
            SetVehicleDoorsLockedForAllPlayers(vehicle, true)
            flashLights(vehicle)
            playLockSound(vehicle, true)
            lib.notify({ title = 'Vehicle Control', description = 'Vehicle locked', type = 'warning' })
        else
            SetVehicleDoorsLocked(vehicle, 1)
            SetVehicleDoorsLockedForAllPlayers(vehicle, false)
            flashLights(vehicle)
            playLockSound(vehicle, false)
            lib.notify({ title = 'Vehicle Control', description = 'Vehicle unlocked', type = 'success' })
        end
    else
        lib.notify({ title = 'Vehicle Control', description = 'No vehicle found nearby', type = 'error' })
    end
end, false)


function isPlayerVehicle(vehicle)
    return NetworkHasControlOfEntity(vehicle) and GetEntityModel(vehicle) ~= 0
end

RegisterCommand('vehicleLockToggle', function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then
        vehicle = GetClosestVehicle(coords, 7.0, 0, 70)
    end

    if vehicle ~= 0 and isPlayerVehicle(vehicle) then
        local locked = GetVehicleDoorLockStatus(vehicle)
        if locked == 1 or locked == 0 then
            SetVehicleDoorsLocked(vehicle, 2)
            SetVehicleDoorsLockedForAllPlayers(vehicle, true)
            flashLights(vehicle)
            TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 5.0, 'lock', 0.4)
            lib.notify({ title = 'Vehicle Control', description = 'Vehicle locked', type = 'warning' })
        else
            SetVehicleDoorsLocked(vehicle, 1)
            SetVehicleDoorsLockedForAllPlayers(vehicle, false)
            flashLights(vehicle)
            TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 5.0, 'unlock', 0.4)
            lib.notify({ title = 'Vehicle Control', description = 'Vehicle unlocked', type = 'success' })
        end
    else
        lib.notify({ title = 'Vehicle Control', description = 'No accessible vehicle nearby', type = 'error' })
    end
end, false)
