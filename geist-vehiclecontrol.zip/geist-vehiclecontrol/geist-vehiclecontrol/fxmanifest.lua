fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'Geist'
description 'Vehicle Control with Ownership Check, Lock Sounds, /rd Command'

client_scripts {
    '@ox_lib/init.lua',
    'client.lua'
}

shared_script '@ox_lib/init.lua'
